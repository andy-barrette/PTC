%Generate noise
T=3;%seconds to generate
Fs=48000;%sampling rate

Ns=T*Fs;%number of samples
%generate normal distributed noise
wn=randn(Ns,1);
%scale between -1 and 1
wn=wn/max(abs(min(wn)),max(wn));

%generate a pure tone
tf=250;%frequency (Hz)
T_tone=2;
Ns_tone=T*Fs;
x=1:Ns_tone;
t=sin(2*pi*x*tf/Fs)';

%%filter option 1 - basic butterworth (IIR)
%will probably need a higher order for narrow bands
%cut off frequencies in Hz
w1=200;
w2=300;
[b,a]=butter(3,[w1 w2]/(14400/2),'stop');
fwn=filtfilt(b,a,wn);

%%filter option 2 - full matlab filter design
w1=200;
w2=300;

transwidth=10;%width of trans

%these parameters are pretty strict and thus lead to a large filter which
%takes some time to apply
Astop=60;%attenuation in the first stopband=60dB