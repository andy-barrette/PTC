%Generate noise
T=3;%seconds to generate
Fs=48000;%sampling rate

Ns=T*Fs;%number of samples
%generate normal distributed noise
wn=randn(Ns,1);
%scale between -1 and 1
wn=wn/max(abs(min(wn)),max(wn));

%generate a pure tone
tf=250;%frequency (Hz)
T_tone=2;
Ns_tone=T*Fs;
x=1:Ns_tone;
t=sin(2*pi*x*tf/Fs)';

%%filter option 1 - basic butterworth (IIR)
%will probably need a higher order for narrow bands
w1=200;
w2=300;
[b,a]=butter(3,[w1 w2]/(14400/2),'stop');
fwn=filtfilt(b,a,wn);

transwidth=40;%width of trans

%these parameters are pretty strict and thus lead to a large filter which
%takes some time to apply
Astop=60;%attenuation in the first stopband=60dB
F1_low=w1-transwidth;%edge of the stopband=8400Hz
F1=w1;%edge of passband=10800Hz
F2_low=w2;%closing edge of the passband=15600Hz
F2_high=w2+transwidth;%edge of the second stopband=18000Hz
Apass=1;%amount of ripple allowed in the passband=1 d
%commend out of the one you dont want
%band stop
%bandpassspec=fdesign.bandpass('Fst1,Fp1,Fp2,Fst2,Ast1,Ap,Ast2',w1-transwidth,w1,w2,w2+transwidth,Astop,Apass,Astop,Fs);
%or band pass
bandstopspec=fdesign.bandstop('Fp1,Fst1,Fst2,Fp2,Ap1,Ast,Ap2',w1,w1+transwidth,w2-transwidth,w2,Apass,Astop,Apass,Fs);

%create the actual filter

%choose here which one you want to uncomment
%bandpass
%Filt=design(bandpassspec,'kaiserwin');
%badstop
Filt=design(bandstopspec,'kaiserwin');

fwn=filter(Filt,wn);
toneblock=randi(2,1);%block that contains tone

if toneblock==1
    %play filtered noise+tone
    p1=audioplayer(fwn+t./2,Fs);
    p1.playblocking()
    
    %play filtered noise
    p1=audioplayer(fwn,Fs);
    p1.playblocking()
else
    %play filtered noise
    p1=audioplayer(fwn,Fs);
    p1.playblocking()
    
    %play filtered noise+tone
    p1=audioplayer(fwn+t./2,Fs);
    p1.playblocking()
end