function varargout = startinggui(varargin)
% STARTINGGUI MATLAB code for startinggui.fig
%      STARTINGGUI, by itself, creates a new STARTINGGUI or raises the existing
%      singleton*.
%
%      H = STARTINGGUI returns the handle to a new STARTINGGUI or the handle to
%      the existing singleton*.
%
%      STARTINGGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in STARTINGGUI.M with the given input arguments.
%
%      STARTINGGUI('Property','Value',...) creates a new STARTINGGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before startinggui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to startinggui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help startinggui

% Last Modified by GUIDE v2.5 18-Jul-2012 21:21:20

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @startinggui_OpeningFcn, ...
                   'gui_OutputFcn',  @startinggui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before startinggui is made visible.
function startinggui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to startinggui (see VARARGIN)

% Choose default command line output for startinggui
handles.output = hObject;
handles.options= optionsgui;
handles.intro= introgui;
handles.play= playtonegui;

h1=guidata(handles.options);
h1.next = handles.intro;
guidata(handles.options,h1);

h2=guidata(handles.intro);
h2.next = handles.play;
guidata(handles.intro,h2);

h3=guidata(handles.play);
h3.next = hObject;
guidata(handles.play,h3);

% Update handles structure
guidata(hObject, handles);
handles.output
%set(handles.output,'Visible','off');
set(handles.options,'Visible','off');
set(handles.intro,'Visible','off');
set(handles.play,'Visible','off');
guidata(hObject, handles);

% UIWAIT makes startinggui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = startinggui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in startprogram.
function startprogram_Callback(hObject, eventdata, handles)
% hObject    handle to startprogram (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.output,'Visible','off');
set(handles.options,'Visible','on');
set(handles.intro,'Visible','off');
set(handles.play,'Visible','off');
